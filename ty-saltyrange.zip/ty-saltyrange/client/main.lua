local ShowVoiceRange = false
local ShowTimer = Config.ShowTimer 
local HideAt = Config.HideArt 
local CurrentMarkerID = nil

-- Function for drawing and deleting the marker
function DrawAndDeleteMarker()
    local PlayerPed = PlayerPedId()
    local PlayerPos = GetEntityCoords(PlayerPed)
    local VoiceRange = exports['saltychat']:GetVoiceRange()

    local startTime = GetGameTimer()
    local duration = ShowTimer * 1000

    while ShowVoiceRange do
        local CloudTime = GetCloudTimeAsInt()
        local currentTime = GetGameTimer() - startTime
        local progress = currentTime / duration
        local transparency = math.max(200 - math.floor(progress * 300), 0)

        if CurrentMarkerID then
            if currentTime >= duration or CloudTime >= HideAt then
                SetEntityAsNoLongerNeeded(CurrentMarkerID)
                CurrentMarkerID = nil
            end
        end

        if not CurrentMarkerID then
            CurrentMarkerID = DrawMarker(Config.MarkerID, PlayerPos.x, PlayerPos.y, PlayerPos.z - 0.95, 0, 0, 0, 0, 0, 0, VoiceRange * 2, VoiceRange * 2, 0.4,  255, 165, 0, transparency, false, false, 2, false, nil, nil, false)
        end

        Wait(0)
    end

    if CurrentMarkerID then
        SetEntityAsNoLongerNeeded(CurrentMarkerID)
        CurrentMarkerID = nil
    end
end

AddEventHandler('SaltyChat_VoiceRangeChanged', function()
    ShowVoiceRange = true
    HideAt = GetCloudTimeAsInt() + ShowTimer
    DrawAndDeleteMarker()
end)
