Config = {}

-- Example: Change this according to the desired marker ID
Config.MarkerID = 1

-- Change the duration of the marker here
Config.ShowTimer = 1
Config.HideArt = -1

-- Change the color of the marker here
Config.RangeColor = {
    R = 255,
    G = 165,
    B = 0,
    A = 50
}
