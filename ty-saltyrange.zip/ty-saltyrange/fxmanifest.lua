fx_version 'cerulean'
game 'gta5'

description 'Saltychat-circle by TREETY CODES'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_script 'client/main.lua'

dependency 'saltychat'

lua54 'yes'